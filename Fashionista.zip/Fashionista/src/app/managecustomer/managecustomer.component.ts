import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-managecustomer',
  templateUrl: './managecustomer.component.html',
  styleUrls: ['./managecustomer.component.css']
})
export class ManagecustomerComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
