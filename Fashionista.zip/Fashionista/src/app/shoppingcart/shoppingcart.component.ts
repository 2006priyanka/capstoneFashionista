
import { Component, Input, OnInit } from '@angular/core';
import { IShop } from '../entities/shopping/shop.model';
import { ShopService } from '../entities/shopping/shop.service';

@Component({
  selector: 'app-shoppingcart',
  templateUrl: './shoppingcart.component.html',
  styleUrls: ['./shoppingcart.component.css']
})
export class ShoppingcartComponent implements OnInit {
  shops: Array<IShop> = [];
  @Input() shopToDisplay: IShop = null;
  selectedShop: IShop;

  constructor(protected shopService: ShopService) { }

  ngOnInit(): void {
    this.loadAll();
  }
  delete(id: string) {
    this.shopService.delete(id).then((result: any) => this.loadAll());
    alert(name)
  }
  private loadAll() {
    this.shopService
      .get()
      .then((result: Array<IShop>) => {
        this.shops = result;
        console.log(this.shops);
      });
  }


}
