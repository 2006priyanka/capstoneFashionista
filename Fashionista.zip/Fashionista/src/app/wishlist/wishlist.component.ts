import { Component, Input, OnInit } from '@angular/core';
import { IWish } from '../entities/wishlist/wish.model';
import { WishService } from '../entities/wishlist/wish.service';

@Component({
  selector: 'app-wishlist',
  templateUrl: './wishlist.component.html',
  styleUrls: ['./wishlist.component.css']
})
export class WishlistComponent implements OnInit {

  wishs: Array<IWish> = [];
  @Input() wishToDisplay: IWish = null;
  selectedWish: IWish;

  constructor(protected wishService: WishService) { }

  ngOnInit(): void {
    this.loadAll();
  }
  delete(id: string) {
    this.wishService.delete(id).then((result: any) => this.loadAll());
    alert(name)
  }
  private loadAll() {
    this.wishService
      .get()
      .then((result: Array<IWish>) => {
        this.wishs = result;
        console.log(this.wishs);
      });
  }


}
